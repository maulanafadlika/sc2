#include <stdio.h>
#include <stdlib.h>

int a, b, i, input;
char ulang;
