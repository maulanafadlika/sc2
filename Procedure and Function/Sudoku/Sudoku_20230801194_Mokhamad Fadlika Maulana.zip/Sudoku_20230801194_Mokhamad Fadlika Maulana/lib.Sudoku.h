#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 4
typedef int matriksint[MAX_SIZE][MAX_SIZE];

int i,j,k=1;

void tentukan(matriksint M1);
void inisiasi(matriksint M2, matriksint M1, int a);
int periksa(matriksint M1, matriksint M2, int a);
void baca(matriksint M1, matriksint M2, int a);
void tulis(matriksint M1, matriksint M2, int a);
