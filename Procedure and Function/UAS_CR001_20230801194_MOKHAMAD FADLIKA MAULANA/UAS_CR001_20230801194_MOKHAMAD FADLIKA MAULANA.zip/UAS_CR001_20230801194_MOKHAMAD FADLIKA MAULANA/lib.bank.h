#include <stdio.h>
#include <stdlib.h>

// Menambahkan typedef untuk struktur
typedef struct
{
    int noRekeningTujuan;
    int nominal;
} TransferTransaction;
