#include "stdio.h"

void koncel(int)


